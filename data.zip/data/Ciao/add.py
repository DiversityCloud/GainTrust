ff = open("./Ciao_trust_new.txt", "w")

with open("./Ciao_trust.txt", "r") as f:
    for line in f:
        line = line.strip()
        line += " 1 1"
        ff.writelines(f"{line}\n")
ff.close()